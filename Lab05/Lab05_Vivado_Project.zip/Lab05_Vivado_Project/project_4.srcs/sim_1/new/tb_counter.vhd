library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_counter is
end tb_counter;

architecture Behavioral of tb_counter is
    constant CLK_PERIOD: time := 10 ns;
    signal reset : std_logic;
    signal clk : std_logic;
    signal hex_out : std_logic_vector(15 downto 0);
    signal phase_count : std_logic_vector(1 downto 0);
begin
    dut: entity work.hex_sec_counter(behavioral)
    port map (
        clk => clk,
        reset => reset,
        hex_out => hex_out,
        phase_count => phase_count
    );

    clock_process: process
    begin
        clk <= '0';
        wait for CLK_PERIOD/2;
        clk <= '1';
        wait for CLK_PERIOD/2;
    end process;

    sim_process: process
    begin
        reset <= '1';
        wait for 50 ns;
        reset <= '0';
        wait for 50 ns;
        wait for 150 ms;
        wait;
    end process;
end Behavioral;