library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_top_seven_segment is
end tb_top_seven_segment;

architecture Behavioral of tb_top_seven_segment is
    constant CLK_PERIOD: time := 10 ns;
    signal reset: std_logic;
    signal clk: std_logic;
    signal an : std_logic_vector(3 downto 0);
    signal cat: std_logic_vector(6 downto 0);
begin
    dut: entity work.top_seven_segment(structural)
    port map (
        clk => clk,
        reset => reset,
        an => an,
        cat => cat
    );

    clock_process: process
    begin
        clk <= '0';
        wait for CLK_PERIOD/2;
        clk <= '1';
        wait for CLK_PERIOD/2;
    end process;

    sim_process: process
    begin
        reset <= '1';
        wait for 30 ns;
        reset <= '0';
        wait for 100 ns;
        wait for 100 ms;
        wait;
    end process;
end Behavioral;