library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all; 

entity hex_sec_counter is
    port (
        clk             : in  std_logic;
        reset           : in  std_logic;
        hex_out         : out std_logic_vector(15 downto 0); 
        phase_count     : out std_logic_vector(1 downto 0)
    );
end entity hex_sec_counter;

architecture behavioral of hex_sec_counter is
    constant SEC_LIMIT : natural := 99999999;
    signal clk_count   : unsigned(26 downto 0) := (others => '0');
    signal seconds     : unsigned(15 downto 0) := (others => '0');
begin
    process(clk, reset)
    begin
        if reset = '1' then
            clk_count <= (others => '0');
            seconds   <= (others => '0');
        elsif rising_edge(clk) then
            if clk_count = to_unsigned(SEC_LIMIT, clk_count'length) then
                clk_count <= (others => '0');
                seconds <= seconds + 1;
            else
                clk_count <= clk_count + 1;
            end if;
        end if;
    end process;
    
    hex_out <= std_logic_vector(seconds);
    phase_count <= std_logic_vector(clk_count(19 downto 18)); 

end architecture behavioral;