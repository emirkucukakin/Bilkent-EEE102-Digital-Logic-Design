library ieee;
use ieee.std_logic_1164.all;

entity segment_driver is
  port (
    phase_count       : in std_logic_vector(1 downto 0);

       num_in      : in std_logic_vector(15 downto 0);
       an_out      : out std_logic_vector(3 downto 0);
       hex_out_to_dec : out std_logic_vector(3 downto 0)
  );
end entity segment_driver;

architecture behavioral of segment_driver is
begin
  process(phase_count, num_in)
  begin
       case phase_count is
         when "00" =>
           an_out <= "0111";
           hex_out_to_dec <= num_in(15 downto 12);
         when "01" =>
           an_out <= "1011";
           hex_out_to_dec <= num_in(11 downto 8);
         when "10" =>
           an_out <= "1101";
           hex_out_to_dec <= num_in(7 downto 4);
         when "11" =>
           an_out <= "1110";
           hex_out_to_dec <= num_in(3 downto 0);
         when others =>

           an_out <= "1111";
           hex_out_to_dec <= (others => '0');
       end case;
  end process;
end architecture behavioral;
