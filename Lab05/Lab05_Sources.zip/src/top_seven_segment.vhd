library ieee;
use ieee.std_logic_1164.all;

entity top_seven_segment is
  port (
       clk   : in std_logic;
       reset : in std_logic;
       an    : out std_logic_vector(3 downto 0);
       cat   : out std_logic_vector(6 downto 0)
  );
end entity top_seven_segment;

architecture structural of top_seven_segment is

  signal hex_val       : std_logic_vector(15 downto 0);
  signal phase_sig : std_logic_vector(1 downto 0);
  signal hex_to_dec : std_logic_vector(3 downto 0);

 component hex_sec_counter
   port (
        clk       : in std_logic;
        reset      : in std_logic;
        hex_out       : out std_logic_vector(15 downto 0);
        phase_count     : out std_logic_vector(1 downto 0)
   );
 end component;

 component segment_driver
   port (
        phase_count     : in std_logic_vector(1 downto 0);
        num_in        : in std_logic_vector(15 downto 0);
        an_out      : out std_logic_vector(3 downto 0);
        hex_out_to_dec : out std_logic_vector(3 downto 0)
   );
 end component;

 component hex_decoder
   port (
        hex_in    : in std_logic_vector(3 downto 0);
        cat_out   : out std_logic_vector(6 downto 0)
   );

  end component;

begin
  U1_Counter : hex_sec_counter
  port map (
       clk      => clk,
       reset     => reset,
       hex_out     => hex_val,
       phase_count => phase_sig
  );

  U2_Driver : segment_driver
  port map (
       phase_count        => phase_sig,
       num_in         => hex_val,
       an_out        => an,
       hex_out_to_dec => hex_to_dec
  );

  U3_Decoder : hex_decoder
  port map (
       hex_in => hex_to_dec,
       cat_out => cat
  );

end architecture structural;
