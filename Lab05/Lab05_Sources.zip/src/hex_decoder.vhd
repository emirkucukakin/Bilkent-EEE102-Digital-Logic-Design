library ieee;
use ieee.std_logic_1164.all;

entity hex_decoder is
  port (
       hex_in      : in std_logic_vector(3 downto 0);
       cat_out     : out std_logic_vector(6 downto 0)
  );
end entity hex_decoder;

architecture behavioral of hex_decoder is
begin
  process(hex_in)
  begin
       case hex_in is
         when "0000" => cat_out <= "1000000";
         when "0001" => cat_out <= "1111001";

       when "0010" => cat_out <= "0100100";
       when "0011" => cat_out <= "0110000";
       when "0100" => cat_out <= "0011001";
       when "0101" => cat_out <= "0010010";
       when "0110" => cat_out <= "0000010";
       when "0111" => cat_out <= "1111000";
       when "1000" => cat_out <= "0000000";
       when "1001" => cat_out <= "0010000";
       when "1010" => cat_out <= "0001000";
       when "1011" => cat_out <= "0000011";
       when "1100" => cat_out <= "1000110";
       when "1101" => cat_out <= "0100001";
       when "1110" => cat_out <= "0000110";
       when "1111" => cat_out <= "0001110";
       when others => cat_out <= "1111111";
    end case;
  end process;
end architecture behavioral;
