set_property PACKAGE_PIN V17 [get_ports {A[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {A[0]}]

set_property PACKAGE_PIN V16 [get_ports {A[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {A[1]}]

set_property PACKAGE_PIN W16 [get_ports {A[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {A[2]}]

set_property PACKAGE_PIN W17 [get_ports {A[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {A[3]}]

set_property PACKAGE_PIN W15 [get_ports {B[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {B[0]}]

set_property PACKAGE_PIN V15 [get_ports {B[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {B[1]}]

set_property PACKAGE_PIN W14 [get_ports {B[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {B[2]}]

set_property PACKAGE_PIN W13 [get_ports {B[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {B[3]}]

set_property PACKAGE_PIN U1 [get_ports s0]
set_property IOSTANDARD LVCMOS33 [get_ports s0]

set_property PACKAGE_PIN T1 [get_ports s1]
set_property IOSTANDARD LVCMOS33 [get_ports s1]

set_property PACKAGE_PIN R2 [get_ports s2]
set_property IOSTANDARD LVCMOS33 [get_ports s2]

set_property PACKAGE_PIN U16 [get_ports {dout_0[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {dout_0[0]}]

set_property PACKAGE_PIN E19 [get_ports {dout_0[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {dout_0[1]}]

set_property PACKAGE_PIN U19 [get_ports {dout_0[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {dout_0[2]}]

set_property PACKAGE_PIN V19 [get_ports {dout_0[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {dout_0[3]}]

set_property PACKAGE_PIN W18 [get_ports {dout_0[4]}]
set_property IOSTANDARD LVCMOS33 [get_ports {dout_0[4]}]
