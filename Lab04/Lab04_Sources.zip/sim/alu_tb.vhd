library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity alu_tb is
end alu_tb;

architecture behavior of alu_tb is
  component alu_design_wrapper
  port(
       A : in std_logic_vector(3 downto 0);
       B : in std_logic_vector(3 downto 0);
       s0 : in std_logic;
       s1 : in std_logic;
       s2 : in std_logic;
       dout_0: out std_logic_vector(4 downto 0)
  );
  end component;

  signal A_tb: std_logic_vector(3 downto 0) := (others => '0');

 signal B_tb: std_logic_vector(3 downto 0) := (others => '0');
 signal s0_tb: std_logic := '0';
 signal s1_tb: std_logic := '0';
 signal s2_tb: std_logic := '0';
 signal Out_tb: std_logic_vector(4 downto 0);
begin
 uut: alu_design_wrapper port map (
      A => A_tb,
      B => B_tb,
      s0 => s0_tb,
      s1 => s1_tb,
      s2 => s2_tb,
      dout_0 => Out_tb
 );

 stim_proc: process
      variable sel_var: unsigned(2 downto 0);
 begin
      for a_int in 0 to 15 loop
        A_tb <= std_logic_vector(to_unsigned(a_int, 4));
        for b_int in 0 to 15 loop
          B_tb <= std_logic_vector(to_unsigned(b_int, 4));
          for sel_int in 0 to 7 loop
            sel_var := to_unsigned(sel_int, 3);
            s2_tb <= sel_var(2);
            s1_tb <= sel_var(1);
            s0_tb <= sel_var(0);
            wait for 1 ns;

       end loop;
     end loop;
   end loop;
 end process;
end behavior;
