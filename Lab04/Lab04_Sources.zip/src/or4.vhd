library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity or4 is
Port(
     A: in std_logic_vector (3 downto 0);
     B: in std_logic_vector (3 downto 0);
     res: out std_logic_vector (3 downto 0)
);
end or4;

architecture Behavioral of or4 is
begin
     res <= A or B;
end Behavioral;
