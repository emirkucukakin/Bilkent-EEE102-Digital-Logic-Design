library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mux2to1_4bit is
Port(
     in0: in std_logic_vector (3 downto 0);
     in1: in std_logic_vector (3 downto 0);
     sel: in std_logic;
     mux_out: out std_logic_vector (3 downto 0)
);
end mux2to1_4bit;

architecture Behavioral of mux2to1_4bit is
     signal sel_vector: std_logic_vector (3 downto 0);
     signal not_sel_vector: std_logic_vector (3 downto 0);
begin

     sel_vector <= (others => sel);
     not_sel_vector <= not sel_vector;
     mux_out <= (in0 and not_sel_vector) or (in1 and sel_vector);
end Behavioral;
