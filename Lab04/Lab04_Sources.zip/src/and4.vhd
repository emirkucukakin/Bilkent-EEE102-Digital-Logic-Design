library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity and4 is

Port(
     A: in std_logic_vector (3 downto 0);
     B: in std_logic_vector (3 downto 0);
     res: out std_logic_vector (3 downto 0)
);
end and4;

architecture Behavioral of and4 is
begin
     res <= A and B;
end Behavioral;
