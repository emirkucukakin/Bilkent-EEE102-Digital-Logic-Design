library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity xor4 is
Port(
     A: in std_logic_vector (3 downto 0);
     B: in std_logic_vector (3 downto 0);
     res: out std_logic_vector (3 downto 0)
);
end xor4;

architecture Behavioral of xor4 is
begin
     res <= A xor B;
end Behavioral;
