library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity one_adder is
Port(
     A: in std_logic;
     B: in std_logic;
     Cin: in std_logic;
     Sum: out std_logic;
     Cout: out std_logic
);
end one_adder;

architecture Behavioral of one_adder is
begin
     Sum <= A xor B xor Cin;
     Cout <= (A and B) or (Cin and (A xor B));
end Behavioral;
