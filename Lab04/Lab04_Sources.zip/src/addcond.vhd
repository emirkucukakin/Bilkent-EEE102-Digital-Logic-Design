library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity addcond is
Port(
     s0: in std_logic;
     s1: in std_logic;
     s2: in std_logic;
     in0: in std_logic;
     in1: in std_logic;
     B_in: in std_logic_vector (3 downto 0);
     out0: out std_logic
);
end addcond;

architecture Behavioral of addcond is
     signal is_addition: std_logic;
     signal is_negation: std_logic;
     signal negation_error: std_logic;
     signal is_subtraction: std_logic;
begin
     is_addition <= not s0 and not s1 and not s2;

  is_negation <= s0 and s1 and s2;
  is_subtraction <= not s2 and not s1 and s0;
  negation_error <= B_in(3) and not B_in(2) and not B_in(1) and not B_in(0);
  out0 <= (is_addition and in0) or (is_negation and negation_error) or (is_subtraction and
in1);
end Behavioral;
