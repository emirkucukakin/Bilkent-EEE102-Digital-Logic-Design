library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity shiftleft is
Port(
     A: in std_logic_vector (3 downto 0);
     res: out std_logic_vector (3 downto 0)
);
end shiftleft;

architecture Behavioral of shiftleft is
begin
     res <= A(2 downto 0) & '0';
end Behavioral;
