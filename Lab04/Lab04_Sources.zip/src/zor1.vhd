library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity zor1 is
Port(
     A: in std_logic;
     B: in std_logic;
     res: out std_logic
);

end zor1;

architecture Behavioral of zor1 is
begin
     res <= A xor B;
end Behavioral;
