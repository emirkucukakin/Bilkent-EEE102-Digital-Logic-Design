library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity shiftright is

Port(
     A: in std_logic_vector (3 downto 0);
     res: out std_logic_vector (3 downto 0)
);
end shiftright;

architecture Behavioral of shiftright is
begin
     res <= '0' & A(3 downto 1);
end Behavioral;
