library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity inverter4 is
Port(
     Ain: in std_logic_vector (3 downto 0);
     Aout: out std_logic_vector (3 downto 0)
);
end inverter4;

architecture Behavioral of inverter4 is
begin
     Aout <= not Ain;
end Behavioral;
