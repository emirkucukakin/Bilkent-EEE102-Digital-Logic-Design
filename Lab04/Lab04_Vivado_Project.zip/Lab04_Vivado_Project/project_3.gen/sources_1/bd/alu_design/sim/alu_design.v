//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Feb 25 16:39:55 2026
//Host        : AsusEmirK running 64-bit major release  (build 9200)
//Command     : generate_target alu_design.bd
//Design      : alu_design
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "alu_design,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=alu_design,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=64,numReposBlks=60,numNonXlnxBlks=0,numHierBlks=4,maxHierDepth=1,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=28,numPkgbdBlks=4,bdsource=USER,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "alu_design.hwdef" *) 
module alu_design
   (A,
    B,
    dout_0,
    s0,
    s1,
    s2);
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.A DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.A, LAYERED_METADATA undef" *) input [3:0]A;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.B DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.B, LAYERED_METADATA undef" *) input [3:0]B;
  output [4:0]dout_0;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.S0 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.S0, LAYERED_METADATA undef" *) input s0;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.S1 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.S1, LAYERED_METADATA undef" *) input s1;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.S2 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.S2, LAYERED_METADATA undef" *) input s2;

  wire [3:0]A;
  wire [3:0]B;
  wire addcond_0_out0;
  wire [3:0]and4_0_res;
  wire design_1_0_Cout_0;
  wire [3:0]design_1_0_dout_0;
  wire [3:0]design_1_1_dout_0;
  wire [3:0]design_2_0_dout_0;
  wire design_2_0_res_0;
  wire [3:0]design_3_0_mux_out_0;
  wire [4:0]dout_0;
  wire [3:0]ilconstant_0_dout;
  wire [3:0]inverter4_0_Aout;
  wire [3:0]or4_0_res;
  wire s0;
  wire s1;
  wire s2;
  wire [3:0]shiftleft_0_res;
  wire [3:0]shiftright_0_res;
  wire [3:0]xor4_0_res;

  alu_design_addcond_0_0 addcond_0
       (.B_in(A),
        .in0(design_1_0_Cout_0),
        .in1(design_2_0_res_0),
        .out0(addcond_0_out0),
        .s0(s0),
        .s1(s1),
        .s2(s2));
  alu_design_and4_0_0 and4_0
       (.A(A),
        .B(B),
        .res(and4_0_res));
  design_1_inst_0 design_1_0
       (.A(A),
        .B(B),
        .Cout_0(design_1_0_Cout_0),
        .dout_0(design_1_0_dout_0));
  design_1_inst_1 design_1_1
       (.A(inverter4_0_Aout),
        .B(ilconstant_0_dout),
        .dout_0(design_1_1_dout_0));
  design_2_inst_0 design_2_0
       (.A(A),
        .B(B),
        .dout_0(design_2_0_dout_0),
        .res_0(design_2_0_res_0));
  design_3_inst_0 design_3_0
       (.in0(design_1_0_dout_0),
        .in1(design_2_0_dout_0),
        .in2(or4_0_res),
        .in3(and4_0_res),
        .in4(shiftleft_0_res),
        .in5(xor4_0_res),
        .in6(shiftright_0_res),
        .in7(design_1_1_dout_0),
        .mux_out_0(design_3_0_mux_out_0),
        .s0(s0),
        .s1(s1),
        .s2(s2));
  assign dout_0 = {addcond_0_out0, design_3_0_mux_out_0};
  assign ilconstant_0_dout = 4'h1;
  alu_design_inverter4_0_0 inverter4_0
       (.Ain(A),
        .Aout(inverter4_0_Aout));
  alu_design_or4_0_0 or4_0
       (.A(A),
        .B(B),
        .res(or4_0_res));
  alu_design_shiftleft_0_0 shiftleft_0
       (.A(A),
        .res(shiftleft_0_res));
  alu_design_shiftright_0_0 shiftright_0
       (.A(A),
        .res(shiftright_0_res));
  alu_design_xor4_0_0 xor4_0
       (.A(A),
        .B(B),
        .res(xor4_0_res));
endmodule
