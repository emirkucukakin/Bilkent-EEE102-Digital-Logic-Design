-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Wed Feb 25 15:47:57 2026
-- Host        : AsusEmirK running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/emirk/project_3/project_3.gen/sources_1/bd/alu_design/bd/design_3_inst_0/ip/design_3_inst_0_mux2to1_4bit_2_0/design_3_inst_0_mux2to1_4bit_2_0_sim_netlist.vhdl
-- Design      : design_3_inst_0_mux2to1_4bit_2_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_3_inst_0_mux2to1_4bit_2_0_mux2to1_4bit is
  port (
    mux_out : out STD_LOGIC_VECTOR ( 3 downto 0 );
    in0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    sel : in STD_LOGIC;
    in1 : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_3_inst_0_mux2to1_4bit_2_0_mux2to1_4bit : entity is "mux2to1_4bit";
end design_3_inst_0_mux2to1_4bit_2_0_mux2to1_4bit;

architecture STRUCTURE of design_3_inst_0_mux2to1_4bit_2_0_mux2to1_4bit is
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \mux_out[0]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \mux_out[1]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \mux_out[2]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \mux_out[3]_INST_0\ : label is "soft_lutpair1";
begin
\mux_out[0]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => in0(0),
      I1 => sel,
      I2 => in1(0),
      O => mux_out(0)
    );
\mux_out[1]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => in0(1),
      I1 => sel,
      I2 => in1(1),
      O => mux_out(1)
    );
\mux_out[2]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => in0(2),
      I1 => sel,
      I2 => in1(2),
      O => mux_out(2)
    );
\mux_out[3]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => in0(3),
      I1 => sel,
      I2 => in1(3),
      O => mux_out(3)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_3_inst_0_mux2to1_4bit_2_0 is
  port (
    in0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    sel : in STD_LOGIC;
    mux_out : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_3_inst_0_mux2to1_4bit_2_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_3_inst_0_mux2to1_4bit_2_0 : entity is "design_3_inst_0_mux2to1_4bit_2_0,mux2to1_4bit,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_3_inst_0_mux2to1_4bit_2_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_3_inst_0_mux2to1_4bit_2_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of design_3_inst_0_mux2to1_4bit_2_0 : entity is "mux2to1_4bit,Vivado 2025.2";
end design_3_inst_0_mux2to1_4bit_2_0;

architecture STRUCTURE of design_3_inst_0_mux2to1_4bit_2_0 is
begin
inst: entity work.design_3_inst_0_mux2to1_4bit_2_0_mux2to1_4bit
     port map (
      in0(3 downto 0) => in0(3 downto 0),
      in1(3 downto 0) => in1(3 downto 0),
      mux_out(3 downto 0) => mux_out(3 downto 0),
      sel => sel
    );
end STRUCTURE;
