//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Feb 25 16:39:55 2026
//Host        : AsusEmirK running 64-bit major release  (build 9200)
//Command     : generate_target design_2_inst_0_wrapper.bd
//Design      : design_2_inst_0_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module design_2_inst_0_wrapper
   (A,
    B,
    dout_0,
    res_0);
  input [3:0]A;
  input [3:0]B;
  output [3:0]dout_0;
  output res_0;

  wire [3:0]A;
  wire [3:0]B;
  wire [3:0]dout_0;
  wire res_0;

  design_2_inst_0 design_2_inst_0_i
       (.A(A),
        .B(B),
        .dout_0(dout_0),
        .res_0(res_0));
endmodule
