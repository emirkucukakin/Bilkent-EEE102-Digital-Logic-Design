//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Feb 25 16:39:56 2026
//Host        : AsusEmirK running 64-bit major release  (build 9200)
//Command     : generate_target design_1_inst_1.bd
//Design      : design_1_inst_1
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "design_1_inst_1,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_1_inst_1,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=14,numReposBlks=14,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=4,numPkgbdBlks=0,bdsource=C_/Users/emirk/project_3/project_3.srcs/sources_1/bd/design_1/design_1.bd,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "design_1_inst_1.hwdef" *) 
module design_1_inst_1
   (A,
    B,
    Cout_0,
    dout_0);
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.A DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.A, LAYERED_METADATA undef" *) input [3:0]A;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.B DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.B, LAYERED_METADATA undef" *) input [3:0]B;
  output Cout_0;
  output [3:0]dout_0;

  wire [3:0]A;
  wire [3:0]B;
  wire Cout_0;
  wire [3:0]dout_0;
  wire [0:0]ilconstant_0_dout;
  wire one_adder_0_Cout;
  wire one_adder_0_Sum;
  wire one_adder_1_Cout;
  wire one_adder_1_Sum;
  wire one_adder_2_Cout;
  wire one_adder_2_Sum;
  wire one_adder_3_Sum;
  wire [0:0]xlslice_0_Dout;
  wire [0:0]xlslice_1_Dout;
  wire [0:0]xlslice_2_Dout;
  wire [0:0]xlslice_3_Dout;
  wire [0:0]xlslice_4_Dout;
  wire [0:0]xlslice_5_Dout;
  wire [0:0]xlslice_6_Dout;
  wire [0:0]xlslice_7_Dout;

  assign dout_0 = {one_adder_3_Sum, one_adder_2_Sum, one_adder_1_Sum, one_adder_0_Sum};
  assign ilconstant_0_dout = 1'h0;
  design_1_inst_1_one_adder_0_0 one_adder_0
       (.A(xlslice_0_Dout),
        .B(xlslice_4_Dout),
        .Cin(ilconstant_0_dout),
        .Cout(one_adder_0_Cout),
        .Sum(one_adder_0_Sum));
  design_1_inst_1_one_adder_1_0 one_adder_1
       (.A(xlslice_1_Dout),
        .B(xlslice_5_Dout),
        .Cin(one_adder_0_Cout),
        .Cout(one_adder_1_Cout),
        .Sum(one_adder_1_Sum));
  design_1_inst_1_one_adder_2_0 one_adder_2
       (.A(xlslice_2_Dout),
        .B(xlslice_6_Dout),
        .Cin(one_adder_1_Cout),
        .Cout(one_adder_2_Cout),
        .Sum(one_adder_2_Sum));
  design_1_inst_1_one_adder_3_0 one_adder_3
       (.A(xlslice_3_Dout),
        .B(xlslice_7_Dout),
        .Cin(one_adder_2_Cout),
        .Cout(Cout_0),
        .Sum(one_adder_3_Sum));
  design_1_inst_1_xlslice_0_0 xlslice_0
       (.Din(A),
        .Dout(xlslice_0_Dout));
  design_1_inst_1_xlslice_1_0 xlslice_1
       (.Din(A),
        .Dout(xlslice_1_Dout));
  design_1_inst_1_xlslice_2_0 xlslice_2
       (.Din(A),
        .Dout(xlslice_2_Dout));
  design_1_inst_1_xlslice_3_0 xlslice_3
       (.Din(A),
        .Dout(xlslice_3_Dout));
  design_1_inst_1_xlslice_4_0 xlslice_4
       (.Din(B),
        .Dout(xlslice_4_Dout));
  design_1_inst_1_xlslice_5_0 xlslice_5
       (.Din(B),
        .Dout(xlslice_5_Dout));
  design_1_inst_1_xlslice_6_0 xlslice_6
       (.Din(B),
        .Dout(xlslice_6_Dout));
  design_1_inst_1_xlslice_7_0 xlslice_7
       (.Din(B),
        .Dout(xlslice_7_Dout));
endmodule
