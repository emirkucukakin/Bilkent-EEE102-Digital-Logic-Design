-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Wed Feb 25 15:47:57 2026
-- Host        : AsusEmirK running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/emirk/project_3/project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/ip/design_2_inst_0_one_adder_3_0/design_2_inst_0_one_adder_3_0_sim_netlist.vhdl
-- Design      : design_2_inst_0_one_adder_3_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_2_inst_0_one_adder_3_0_one_adder is
  port (
    Cout : out STD_LOGIC;
    B : in STD_LOGIC;
    A : in STD_LOGIC;
    Cin : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_2_inst_0_one_adder_3_0_one_adder : entity is "one_adder";
end design_2_inst_0_one_adder_3_0_one_adder;

architecture STRUCTURE of design_2_inst_0_one_adder_3_0_one_adder is
begin
\Cout__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => B,
      I1 => A,
      I2 => Cin,
      O => Cout
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_2_inst_0_one_adder_3_0 is
  port (
    A : in STD_LOGIC;
    B : in STD_LOGIC;
    Cin : in STD_LOGIC;
    Sum : out STD_LOGIC;
    Cout : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_2_inst_0_one_adder_3_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_2_inst_0_one_adder_3_0 : entity is "design_2_inst_0_one_adder_3_0,one_adder,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_2_inst_0_one_adder_3_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_2_inst_0_one_adder_3_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of design_2_inst_0_one_adder_3_0 : entity is "one_adder,Vivado 2025.2";
end design_2_inst_0_one_adder_3_0;

architecture STRUCTURE of design_2_inst_0_one_adder_3_0 is
begin
Sum_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => Cin,
      I1 => A,
      I2 => B,
      O => Sum
    );
inst: entity work.design_2_inst_0_one_adder_3_0_one_adder
     port map (
      A => A,
      B => B,
      Cin => Cin,
      Cout => Cout
    );
end STRUCTURE;
