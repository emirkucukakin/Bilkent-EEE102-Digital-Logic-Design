//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Feb 25 16:39:56 2026
//Host        : AsusEmirK running 64-bit major release  (build 9200)
//Command     : generate_target design_3_inst_0_wrapper.bd
//Design      : design_3_inst_0_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module design_3_inst_0_wrapper
   (in0,
    in1,
    in2,
    in3,
    in4,
    in5,
    in6,
    in7,
    mux_out_0,
    s0,
    s1,
    s2);
  input [3:0]in0;
  input [3:0]in1;
  input [3:0]in2;
  input [3:0]in3;
  input [3:0]in4;
  input [3:0]in5;
  input [3:0]in6;
  input [3:0]in7;
  output [3:0]mux_out_0;
  input s0;
  input s1;
  input s2;

  wire [3:0]in0;
  wire [3:0]in1;
  wire [3:0]in2;
  wire [3:0]in3;
  wire [3:0]in4;
  wire [3:0]in5;
  wire [3:0]in6;
  wire [3:0]in7;
  wire [3:0]mux_out_0;
  wire s0;
  wire s1;
  wire s2;

  design_3_inst_0 design_3_inst_0_i
       (.in0(in0),
        .in1(in1),
        .in2(in2),
        .in3(in3),
        .in4(in4),
        .in5(in5),
        .in6(in6),
        .in7(in7),
        .mux_out_0(mux_out_0),
        .s0(s0),
        .s1(s1),
        .s2(s2));
endmodule
