//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Feb 25 16:39:55 2026
//Host        : AsusEmirK running 64-bit major release  (build 9200)
//Command     : generate_target design_2_inst_0.bd
//Design      : design_2_inst_0
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "design_2_inst_0,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_2_inst_0,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=16,numReposBlks=16,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=6,numPkgbdBlks=0,bdsource=C_/Users/emirk/project_3/project_3.srcs/sources_1/bd/design_2/design_2.bd,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "design_2_inst_0.hwdef" *) 
module design_2_inst_0
   (A,
    B,
    dout_0,
    res_0);
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.A DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.A, LAYERED_METADATA undef" *) input [3:0]A;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.B DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.B, LAYERED_METADATA undef" *) input [3:0]B;
  output [3:0]dout_0;
  output res_0;

  wire [3:0]A;
  wire [3:0]B;
  wire [3:0]dout_0;
  wire [0:0]ilconstant_0_dout;
  wire [0:0]ilslice_0_Dout;
  wire [0:0]ilslice_1_Dout;
  wire [0:0]ilslice_2_Dout;
  wire [0:0]ilslice_3_Dout;
  wire [0:0]ilslice_4_Dout;
  wire [0:0]ilslice_5_Dout;
  wire [0:0]ilslice_6_Dout;
  wire [0:0]ilslice_7_Dout;
  wire [3:0]inverter4_0_Aout;
  wire one_adder_0_Cout;
  wire one_adder_0_Sum;
  wire one_adder_1_Cout;
  wire one_adder_1_Sum;
  wire one_adder_2_Cout;
  wire one_adder_2_Sum;
  wire one_adder_3_Cout;
  wire one_adder_3_Sum;
  wire res_0;

  assign dout_0 = {one_adder_3_Sum, one_adder_2_Sum, one_adder_1_Sum, one_adder_0_Sum};
  assign ilconstant_0_dout = 1'h1;
  assign ilslice_0_Dout = A[0:0];
  assign ilslice_1_Dout = A[1:1];
  assign ilslice_2_Dout = A[2:2];
  assign ilslice_3_Dout = A[3:3];
  assign ilslice_4_Dout = inverter4_0_Aout[0:0];
  assign ilslice_5_Dout = inverter4_0_Aout[1:1];
  assign ilslice_6_Dout = inverter4_0_Aout[2:2];
  assign ilslice_7_Dout = inverter4_0_Aout[3:3];
  design_2_inst_0_inverter4_0_0 inverter4_0
       (.Ain(B),
        .Aout(inverter4_0_Aout));
  design_2_inst_0_one_adder_0_0 one_adder_0
       (.A(ilslice_0_Dout),
        .B(ilslice_4_Dout),
        .Cin(ilconstant_0_dout),
        .Cout(one_adder_0_Cout),
        .Sum(one_adder_0_Sum));
  design_2_inst_0_one_adder_1_0 one_adder_1
       (.A(ilslice_1_Dout),
        .B(ilslice_5_Dout),
        .Cin(one_adder_0_Cout),
        .Cout(one_adder_1_Cout),
        .Sum(one_adder_1_Sum));
  design_2_inst_0_one_adder_2_0 one_adder_2
       (.A(ilslice_2_Dout),
        .B(ilslice_6_Dout),
        .Cin(one_adder_1_Cout),
        .Cout(one_adder_2_Cout),
        .Sum(one_adder_2_Sum));
  design_2_inst_0_one_adder_3_0 one_adder_3
       (.A(ilslice_3_Dout),
        .B(ilslice_7_Dout),
        .Cin(one_adder_2_Cout),
        .Cout(one_adder_3_Cout),
        .Sum(one_adder_3_Sum));
  design_2_inst_0_zor1_0_0 zor1_0
       (.A(one_adder_2_Cout),
        .B(one_adder_3_Cout),
        .res(res_0));
endmodule
