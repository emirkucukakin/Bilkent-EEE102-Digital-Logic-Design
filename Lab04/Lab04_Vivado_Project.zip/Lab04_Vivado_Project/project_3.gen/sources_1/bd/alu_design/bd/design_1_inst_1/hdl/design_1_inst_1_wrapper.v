//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Feb 25 16:39:56 2026
//Host        : AsusEmirK running 64-bit major release  (build 9200)
//Command     : generate_target design_1_inst_1_wrapper.bd
//Design      : design_1_inst_1_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module design_1_inst_1_wrapper
   (A,
    B,
    Cout_0,
    dout_0);
  input [3:0]A;
  input [3:0]B;
  output Cout_0;
  output [3:0]dout_0;

  wire [3:0]A;
  wire [3:0]B;
  wire Cout_0;
  wire [3:0]dout_0;

  design_1_inst_1 design_1_inst_1_i
       (.A(A),
        .B(B),
        .Cout_0(Cout_0),
        .dout_0(dout_0));
endmodule
