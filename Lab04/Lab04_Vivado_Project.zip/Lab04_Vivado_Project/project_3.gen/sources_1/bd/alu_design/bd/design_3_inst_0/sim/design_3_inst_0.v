//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Feb 25 16:39:56 2026
//Host        : AsusEmirK running 64-bit major release  (build 9200)
//Command     : generate_target design_3_inst_0.bd
//Design      : design_3_inst_0
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "design_3_inst_0,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_3_inst_0,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=7,numReposBlks=7,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=7,numPkgbdBlks=0,bdsource=C_/Users/emirk/project_3/project_3.srcs/sources_1/bd/design_3/design_3.bd,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "design_3_inst_0.hwdef" *) 
module design_3_inst_0
   (in0,
    in1,
    in2,
    in3,
    in4,
    in5,
    in6,
    in7,
    mux_out_0,
    s0,
    s1,
    s2);
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.IN0 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.IN0, LAYERED_METADATA undef" *) input [3:0]in0;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.IN1 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.IN1, LAYERED_METADATA undef" *) input [3:0]in1;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.IN2 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.IN2, LAYERED_METADATA undef" *) input [3:0]in2;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.IN3 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.IN3, LAYERED_METADATA undef" *) input [3:0]in3;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.IN4 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.IN4, LAYERED_METADATA undef" *) input [3:0]in4;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.IN5 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.IN5, LAYERED_METADATA undef" *) input [3:0]in5;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.IN6 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.IN6, LAYERED_METADATA undef" *) input [3:0]in6;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.IN7 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.IN7, LAYERED_METADATA undef" *) input [3:0]in7;
  output [3:0]mux_out_0;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.S0 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.S0, LAYERED_METADATA undef" *) input s0;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.S1 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.S1, LAYERED_METADATA undef" *) input s1;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.S2 DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.S2, LAYERED_METADATA undef" *) input s2;

  wire [3:0]in0;
  wire [3:0]in1;
  wire [3:0]in2;
  wire [3:0]in3;
  wire [3:0]in4;
  wire [3:0]in5;
  wire [3:0]in6;
  wire [3:0]in7;
  wire [3:0]mux2to1_4bit_0_mux_out;
  wire [3:0]mux2to1_4bit_1_mux_out;
  wire [3:0]mux2to1_4bit_2_mux_out;
  wire [3:0]mux2to1_4bit_3_mux_out;
  wire [3:0]mux2to1_4bit_4_mux_out;
  wire [3:0]mux2to1_4bit_5_mux_out;
  wire [3:0]mux_out_0;
  wire s0;
  wire s1;
  wire s2;

  design_3_inst_0_mux2to1_4bit_0_0 mux2to1_4bit_0
       (.in0(in0),
        .in1(in1),
        .mux_out(mux2to1_4bit_0_mux_out),
        .sel(s0));
  design_3_inst_0_mux2to1_4bit_1_0 mux2to1_4bit_1
       (.in0(in2),
        .in1(in3),
        .mux_out(mux2to1_4bit_1_mux_out),
        .sel(s0));
  design_3_inst_0_mux2to1_4bit_2_0 mux2to1_4bit_2
       (.in0(in4),
        .in1(in5),
        .mux_out(mux2to1_4bit_2_mux_out),
        .sel(s0));
  design_3_inst_0_mux2to1_4bit_3_0 mux2to1_4bit_3
       (.in0(in6),
        .in1(in7),
        .mux_out(mux2to1_4bit_3_mux_out),
        .sel(s0));
  design_3_inst_0_mux2to1_4bit_4_0 mux2to1_4bit_4
       (.in0(mux2to1_4bit_0_mux_out),
        .in1(mux2to1_4bit_1_mux_out),
        .mux_out(mux2to1_4bit_4_mux_out),
        .sel(s1));
  design_3_inst_0_mux2to1_4bit_5_0 mux2to1_4bit_5
       (.in0(mux2to1_4bit_2_mux_out),
        .in1(mux2to1_4bit_3_mux_out),
        .mux_out(mux2to1_4bit_5_mux_out),
        .sel(s1));
  design_3_inst_0_mux2to1_4bit_6_0 mux2to1_4bit_6
       (.in0(mux2to1_4bit_4_mux_out),
        .in1(mux2to1_4bit_5_mux_out),
        .mux_out(mux_out_0),
        .sel(s2));
endmodule
