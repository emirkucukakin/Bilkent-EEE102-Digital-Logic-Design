-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Wed Feb 25 15:47:56 2026
-- Host        : AsusEmirK running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/emirk/project_3/project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/ip/design_2_inst_0_zor1_0_0/design_2_inst_0_zor1_0_0_stub.vhdl
-- Design      : design_2_inst_0_zor1_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design_2_inst_0_zor1_0_0 is
  Port ( 
    A : in STD_LOGIC;
    B : in STD_LOGIC;
    res : out STD_LOGIC
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_2_inst_0_zor1_0_0 : entity is "design_2_inst_0_zor1_0_0,zor1,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of design_2_inst_0_zor1_0_0 : entity is "design_2_inst_0_zor1_0_0,zor1,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=zor1,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_2_inst_0_zor1_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_2_inst_0_zor1_0_0 : entity is "module_ref";
end design_2_inst_0_zor1_0_0;

architecture stub of design_2_inst_0_zor1_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "A,B,res";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "zor1,Vivado 2025.2";
begin
end;
