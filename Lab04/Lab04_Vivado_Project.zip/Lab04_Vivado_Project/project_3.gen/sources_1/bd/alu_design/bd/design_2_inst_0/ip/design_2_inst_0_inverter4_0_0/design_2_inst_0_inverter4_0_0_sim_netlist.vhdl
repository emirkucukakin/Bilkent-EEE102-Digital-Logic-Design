-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Wed Feb 25 15:46:38 2026
-- Host        : AsusEmirK running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/emirk/project_3/project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/ip/design_2_inst_0_inverter4_0_0/design_2_inst_0_inverter4_0_0_sim_netlist.vhdl
-- Design      : design_2_inst_0_inverter4_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_2_inst_0_inverter4_0_0_inverter4 is
  port (
    Aout : out STD_LOGIC_VECTOR ( 3 downto 0 );
    Ain : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_2_inst_0_inverter4_0_0_inverter4 : entity is "inverter4";
end design_2_inst_0_inverter4_0_0_inverter4;

architecture STRUCTURE of design_2_inst_0_inverter4_0_0_inverter4 is
begin
\Aout[0]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => Ain(0),
      O => Aout(0)
    );
\Aout[1]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => Ain(1),
      O => Aout(1)
    );
\Aout[2]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => Ain(2),
      O => Aout(2)
    );
\Aout[3]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => Ain(3),
      O => Aout(3)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_2_inst_0_inverter4_0_0 is
  port (
    Ain : in STD_LOGIC_VECTOR ( 3 downto 0 );
    Aout : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_2_inst_0_inverter4_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_2_inst_0_inverter4_0_0 : entity is "design_2_inst_0_inverter4_0_0,inverter4,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_2_inst_0_inverter4_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_2_inst_0_inverter4_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of design_2_inst_0_inverter4_0_0 : entity is "inverter4,Vivado 2025.2";
end design_2_inst_0_inverter4_0_0;

architecture STRUCTURE of design_2_inst_0_inverter4_0_0 is
begin
inst: entity work.design_2_inst_0_inverter4_0_0_inverter4
     port map (
      Ain(3 downto 0) => Ain(3 downto 0),
      Aout(3 downto 0) => Aout(3 downto 0)
    );
end STRUCTURE;
