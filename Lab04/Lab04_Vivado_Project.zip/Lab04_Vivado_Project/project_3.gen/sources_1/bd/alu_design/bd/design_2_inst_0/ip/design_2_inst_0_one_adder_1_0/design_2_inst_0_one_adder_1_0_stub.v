// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Wed Feb 25 15:47:56 2026
// Host        : AsusEmirK running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/emirk/project_3/project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/ip/design_2_inst_0_one_adder_1_0/design_2_inst_0_one_adder_1_0_stub.v
// Design      : design_2_inst_0_one_adder_1_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "design_2_inst_0_one_adder_1_0,one_adder,{}" *) (* CORE_GENERATION_INFO = "design_2_inst_0_one_adder_1_0,one_adder,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=one_adder,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "one_adder,Vivado 2025.2" *) 
module design_2_inst_0_one_adder_1_0(A, B, Cin, Sum, Cout)
/* synthesis syn_black_box black_box_pad_pin="A,B,Cin,Sum,Cout" */;
  input A;
  input B;
  input Cin;
  output Sum;
  output Cout;
endmodule
