// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Wed Feb 25 15:47:57 2026
// Host        : AsusEmirK running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/emirk/project_3/project_3.gen/sources_1/bd/alu_design/bd/design_3_inst_0/ip/design_3_inst_0_mux2to1_4bit_4_0/design_3_inst_0_mux2to1_4bit_4_0_sim_netlist.v
// Design      : design_3_inst_0_mux2to1_4bit_4_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_3_inst_0_mux2to1_4bit_4_0,mux2to1_4bit,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "mux2to1_4bit,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module design_3_inst_0_mux2to1_4bit_4_0
   (in0,
    in1,
    sel,
    mux_out);
  input [3:0]in0;
  input [3:0]in1;
  input sel;
  output [3:0]mux_out;

  wire [3:0]in0;
  wire [3:0]in1;
  wire [3:0]mux_out;
  wire sel;

  design_3_inst_0_mux2to1_4bit_4_0_mux2to1_4bit inst
       (.in0(in0),
        .in1(in1),
        .mux_out(mux_out),
        .sel(sel));
endmodule

(* ORIG_REF_NAME = "mux2to1_4bit" *) 
module design_3_inst_0_mux2to1_4bit_4_0_mux2to1_4bit
   (mux_out,
    in0,
    sel,
    in1);
  output [3:0]mux_out;
  input [3:0]in0;
  input sel;
  input [3:0]in1;

  wire [3:0]in0;
  wire [3:0]in1;
  wire [3:0]mux_out;
  wire sel;

  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \mux_out[0]_INST_0 
       (.I0(in0[0]),
        .I1(sel),
        .I2(in1[0]),
        .O(mux_out[0]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \mux_out[1]_INST_0 
       (.I0(in0[1]),
        .I1(sel),
        .I2(in1[1]),
        .O(mux_out[1]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \mux_out[2]_INST_0 
       (.I0(in0[2]),
        .I1(sel),
        .I2(in1[2]),
        .O(mux_out[2]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \mux_out[3]_INST_0 
       (.I0(in0[3]),
        .I1(sel),
        .I2(in1[3]),
        .O(mux_out[3]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
