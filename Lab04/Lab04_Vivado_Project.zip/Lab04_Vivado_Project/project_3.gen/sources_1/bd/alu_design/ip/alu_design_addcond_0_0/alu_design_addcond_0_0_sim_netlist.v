// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Wed Feb 25 15:48:38 2026
// Host        : AsusEmirK running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/emirk/project_3/project_3.gen/sources_1/bd/alu_design/ip/alu_design_addcond_0_0/alu_design_addcond_0_0_sim_netlist.v
// Design      : alu_design_addcond_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "alu_design_addcond_0_0,addcond,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "addcond,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module alu_design_addcond_0_0
   (s0,
    s1,
    s2,
    in0,
    in1,
    B_in,
    out0);
  input s0;
  input s1;
  input s2;
  input in0;
  input in1;
  input [3:0]B_in;
  output out0;

  wire [3:0]B_in;
  wire in0;
  wire in1;
  wire out0;
  wire s0;
  wire s1;
  wire s2;

  alu_design_addcond_0_0_addcond inst
       (.B_in(B_in),
        .in0(in0),
        .in1(in1),
        .out0(out0),
        .s0(s0),
        .s1(s1),
        .s2(s2));
endmodule

(* ORIG_REF_NAME = "addcond" *) 
module alu_design_addcond_0_0_addcond
   (out0,
    in0,
    s2,
    s1,
    s0,
    in1,
    B_in);
  output out0;
  input in0;
  input s2;
  input s1;
  input s0;
  input in1;
  input [3:0]B_in;

  wire [3:0]B_in;
  wire in0;
  wire in1;
  wire out0;
  wire out0_INST_0_i_1_n_0;
  wire s0;
  wire s1;
  wire s2;

  LUT6 #(
    .INIT(64'hC0CFC0CAC0C0C0CA)) 
    out0_INST_0
       (.I0(in0),
        .I1(out0_INST_0_i_1_n_0),
        .I2(s2),
        .I3(s1),
        .I4(s0),
        .I5(in1),
        .O(out0));
  LUT6 #(
    .INIT(64'h0000002000000000)) 
    out0_INST_0_i_1
       (.I0(B_in[3]),
        .I1(B_in[1]),
        .I2(s1),
        .I3(B_in[0]),
        .I4(B_in[2]),
        .I5(s0),
        .O(out0_INST_0_i_1_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
