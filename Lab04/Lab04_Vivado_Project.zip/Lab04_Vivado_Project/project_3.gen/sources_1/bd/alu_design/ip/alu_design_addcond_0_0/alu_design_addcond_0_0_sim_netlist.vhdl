-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Wed Feb 25 15:48:38 2026
-- Host        : AsusEmirK running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/emirk/project_3/project_3.gen/sources_1/bd/alu_design/ip/alu_design_addcond_0_0/alu_design_addcond_0_0_sim_netlist.vhdl
-- Design      : alu_design_addcond_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity alu_design_addcond_0_0_addcond is
  port (
    out0 : out STD_LOGIC;
    in0 : in STD_LOGIC;
    s2 : in STD_LOGIC;
    s1 : in STD_LOGIC;
    s0 : in STD_LOGIC;
    in1 : in STD_LOGIC;
    B_in : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of alu_design_addcond_0_0_addcond : entity is "addcond";
end alu_design_addcond_0_0_addcond;

architecture STRUCTURE of alu_design_addcond_0_0_addcond is
  signal out0_INST_0_i_1_n_0 : STD_LOGIC;
begin
out0_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0CFC0CAC0C0C0CA"
    )
        port map (
      I0 => in0,
      I1 => out0_INST_0_i_1_n_0,
      I2 => s2,
      I3 => s1,
      I4 => s0,
      I5 => in1,
      O => out0
    );
out0_INST_0_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000002000000000"
    )
        port map (
      I0 => B_in(3),
      I1 => B_in(1),
      I2 => s1,
      I3 => B_in(0),
      I4 => B_in(2),
      I5 => s0,
      O => out0_INST_0_i_1_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity alu_design_addcond_0_0 is
  port (
    s0 : in STD_LOGIC;
    s1 : in STD_LOGIC;
    s2 : in STD_LOGIC;
    in0 : in STD_LOGIC;
    in1 : in STD_LOGIC;
    B_in : in STD_LOGIC_VECTOR ( 3 downto 0 );
    out0 : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of alu_design_addcond_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of alu_design_addcond_0_0 : entity is "alu_design_addcond_0_0,addcond,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of alu_design_addcond_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of alu_design_addcond_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of alu_design_addcond_0_0 : entity is "addcond,Vivado 2025.2";
end alu_design_addcond_0_0;

architecture STRUCTURE of alu_design_addcond_0_0 is
begin
inst: entity work.alu_design_addcond_0_0_addcond
     port map (
      B_in(3 downto 0) => B_in(3 downto 0),
      in0 => in0,
      in1 => in1,
      out0 => out0,
      s0 => s0,
      s1 => s1,
      s2 => s2
    );
end STRUCTURE;
