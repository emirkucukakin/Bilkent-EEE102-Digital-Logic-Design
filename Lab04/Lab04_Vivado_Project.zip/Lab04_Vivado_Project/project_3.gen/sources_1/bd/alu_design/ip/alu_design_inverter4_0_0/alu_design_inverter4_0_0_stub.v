// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Wed Feb 25 15:49:06 2026
// Host        : AsusEmirK running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/emirk/project_3/project_3.gen/sources_1/bd/alu_design/ip/alu_design_inverter4_0_0/alu_design_inverter4_0_0_stub.v
// Design      : alu_design_inverter4_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "alu_design_inverter4_0_0,inverter4,{}" *) (* CORE_GENERATION_INFO = "alu_design_inverter4_0_0,inverter4,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=inverter4,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "inverter4,Vivado 2025.2" *) 
module alu_design_inverter4_0_0(Ain, Aout)
/* synthesis syn_black_box black_box_pad_pin="Ain[3:0],Aout[3:0]" */;
  input [3:0]Ain;
  output [3:0]Aout;
endmodule
