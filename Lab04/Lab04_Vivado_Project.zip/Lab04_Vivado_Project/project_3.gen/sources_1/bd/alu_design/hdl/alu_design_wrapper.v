//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Feb 25 16:39:55 2026
//Host        : AsusEmirK running 64-bit major release  (build 9200)
//Command     : generate_target alu_design_wrapper.bd
//Design      : alu_design_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module alu_design_wrapper
   (A,
    B,
    dout_0,
    s0,
    s1,
    s2);
  input [3:0]A;
  input [3:0]B;
  output [4:0]dout_0;
  input s0;
  input s1;
  input s2;

  wire [3:0]A;
  wire [3:0]B;
  wire [4:0]dout_0;
  wire s0;
  wire s1;
  wire s2;

  alu_design alu_design_i
       (.A(A),
        .B(B),
        .dout_0(dout_0),
        .s0(s0),
        .s1(s1),
        .s2(s2));
endmodule
