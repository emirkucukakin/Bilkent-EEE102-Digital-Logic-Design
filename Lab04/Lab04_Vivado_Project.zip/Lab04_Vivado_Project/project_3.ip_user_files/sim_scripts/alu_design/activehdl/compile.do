transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib activehdl/xil_defaultlib
vlib activehdl/xlslice_v1_0_5

vmap xil_defaultlib activehdl/xil_defaultlib
vmap xlslice_v1_0_5 activehdl/xlslice_v1_0_5

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" -l xil_defaultlib -l xlslice_v1_0_5 \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_one_adder_0_0/sim/design_1_inst_0_one_adder_0_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_one_adder_1_0/sim/design_1_inst_0_one_adder_1_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_one_adder_2_0/sim/design_1_inst_0_one_adder_2_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_one_adder_3_0/sim/design_1_inst_0_one_adder_3_0.v" \

vlog -work xlslice_v1_0_5  -v2k5 "+incdir+../../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" -l xil_defaultlib -l xlslice_v1_0_5 \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ipshared/6792/hdl/xlslice_v1_0_vl_rfs.v" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" -l xil_defaultlib -l xlslice_v1_0_5 \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_xlslice_0_0/sim/design_1_inst_0_xlslice_0_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_xlslice_1_0/sim/design_1_inst_0_xlslice_1_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_xlslice_2_0/sim/design_1_inst_0_xlslice_2_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_xlslice_3_0/sim/design_1_inst_0_xlslice_3_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_xlslice_4_0/sim/design_1_inst_0_xlslice_4_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_xlslice_5_0/sim/design_1_inst_0_xlslice_5_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_xlslice_6_0/sim/design_1_inst_0_xlslice_6_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/ip/design_1_inst_0_xlslice_7_0/sim/design_1_inst_0_xlslice_7_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_0/sim/design_1_inst_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/ip/design_2_inst_0_inverter4_0_0/sim/design_2_inst_0_inverter4_0_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/ip/design_2_inst_0_zor1_0_0/sim/design_2_inst_0_zor1_0_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/ip/design_2_inst_0_one_adder_0_0/sim/design_2_inst_0_one_adder_0_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/ip/design_2_inst_0_one_adder_1_0/sim/design_2_inst_0_one_adder_1_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/ip/design_2_inst_0_one_adder_2_0/sim/design_2_inst_0_one_adder_2_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/ip/design_2_inst_0_one_adder_3_0/sim/design_2_inst_0_one_adder_3_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_2_inst_0/sim/design_2_inst_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_3_inst_0/ip/design_3_inst_0_mux2to1_4bit_0_0/sim/design_3_inst_0_mux2to1_4bit_0_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_3_inst_0/ip/design_3_inst_0_mux2to1_4bit_1_0/sim/design_3_inst_0_mux2to1_4bit_1_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_3_inst_0/ip/design_3_inst_0_mux2to1_4bit_2_0/sim/design_3_inst_0_mux2to1_4bit_2_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_3_inst_0/ip/design_3_inst_0_mux2to1_4bit_3_0/sim/design_3_inst_0_mux2to1_4bit_3_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_3_inst_0/ip/design_3_inst_0_mux2to1_4bit_4_0/sim/design_3_inst_0_mux2to1_4bit_4_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_3_inst_0/ip/design_3_inst_0_mux2to1_4bit_5_0/sim/design_3_inst_0_mux2to1_4bit_5_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_3_inst_0/ip/design_3_inst_0_mux2to1_4bit_6_0/sim/design_3_inst_0_mux2to1_4bit_6_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_3_inst_0/sim/design_3_inst_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_one_adder_0_0/sim/design_1_inst_1_one_adder_0_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_one_adder_1_0/sim/design_1_inst_1_one_adder_1_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_one_adder_2_0/sim/design_1_inst_1_one_adder_2_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_one_adder_3_0/sim/design_1_inst_1_one_adder_3_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_xlslice_0_0/sim/design_1_inst_1_xlslice_0_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_xlslice_1_0/sim/design_1_inst_1_xlslice_1_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_xlslice_2_0/sim/design_1_inst_1_xlslice_2_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_xlslice_3_0/sim/design_1_inst_1_xlslice_3_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_xlslice_4_0/sim/design_1_inst_1_xlslice_4_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_xlslice_5_0/sim/design_1_inst_1_xlslice_5_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_xlslice_6_0/sim/design_1_inst_1_xlslice_6_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/ip/design_1_inst_1_xlslice_7_0/sim/design_1_inst_1_xlslice_7_0.v" \
"../../../../project_3.gen/sources_1/bd/alu_design/bd/design_1_inst_1/sim/design_1_inst_1.v" \
"../../../bd/alu_design/ip/alu_design_and4_0_0/sim/alu_design_and4_0_0.v" \
"../../../bd/alu_design/ip/alu_design_or4_0_0/sim/alu_design_or4_0_0.v" \
"../../../bd/alu_design/ip/alu_design_xor4_0_0/sim/alu_design_xor4_0_0.v" \
"../../../bd/alu_design/ip/alu_design_shiftleft_0_0/sim/alu_design_shiftleft_0_0.v" \
"../../../bd/alu_design/ip/alu_design_shiftright_0_0/sim/alu_design_shiftright_0_0.v" \
"../../../bd/alu_design/ip/alu_design_addcond_0_0/sim/alu_design_addcond_0_0.v" \
"../../../bd/alu_design/ip/alu_design_inverter4_0_0/sim/alu_design_inverter4_0_0.v" \
"../../../bd/alu_design/sim/alu_design.v" \

vlog -work xil_defaultlib \
"glbl.v"

