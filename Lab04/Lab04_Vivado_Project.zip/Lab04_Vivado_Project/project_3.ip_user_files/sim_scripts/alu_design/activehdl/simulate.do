transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

asim +access +r +m+alu_design  -L xil_defaultlib -L xlslice_v1_0_5 -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.alu_design xil_defaultlib.glbl

do {alu_design.udo}

run 1000ns

endsim

quit -force
