library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_top_module is

end tb_top_module;

architecture behavior of tb_top_module is

  component top_module
  Port ( system_clock     : in STD_LOGIC;

     ldr_input         : in STD_LOGIC;
     sensor_echo         : in STD_LOGIC;
     button_up          : in STD_LOGIC;
     button_down          : in STD_LOGIC;
     button_left        : in STD_LOGIC;
     sensor_trigger      : out STD_LOGIC;
     alarm_buzzer        : out STD_LOGIC;
     alarm_led         : out STD_LOGIC;
     ldr_status_led      : out STD_LOGIC;
     ext_countdown_led : out STD_LOGIC;
     segment_out         : out STD_LOGIC_VECTOR (6 downto 0);
     anode_out          : out STD_LOGIC_VECTOR (3 downto 0));
 end component;

 signal system_clock : std_logic := '0';
 signal ldr_input : std_logic := '0';
 signal sensor_echo : std_logic := '0';
 signal button_up : std_logic := '0';
 signal button_down : std_logic := '0';
 signal button_left : std_logic := '0';

 -- Çıkış Sinyalleri
 signal sensor_trigger : std_logic;

  signal alarm_buzzer       : std_logic;
  signal alarm_led        : std_logic;
  signal ldr_status_led : std_logic;
  signal ext_countdown_led : std_logic;
  signal segment_out        : std_logic_vector(6 downto 0);
  signal anode_out         : std_logic_vector(3 downto 0);

  constant clock_period : time := 10 ns;

begin

  uut: top_module port map (
        system_clock     => system_clock,
        ldr_input      => ldr_input,
        sensor_echo      => sensor_echo,
        button_up       => button_up,
        button_down       => button_down,
        button_left     => button_left,
        sensor_trigger => sensor_trigger,
        alarm_buzzer     => alarm_buzzer,
        alarm_led      => alarm_led,
        ldr_status_led => ldr_status_led,
        ext_countdown_led => ext_countdown_led,

       segment_out         => segment_out,
       anode_out          => anode_out
 );

 clock_process :process
 begin
      system_clock <= '0';
      wait for clock_period/2;
      system_clock <= '1';
      wait for clock_period/2;
 end process;

 echo_process :process
 begin
      wait until rising_edge(sensor_trigger);
      wait for 10 us;

      sensor_echo <= '1';

      wait for 1740 us;

      sensor_echo <= '0';
      wait for 50 ms;

  end process;

  stim_proc: process
  begin

    ldr_input <= '1';
    button_up <= '0';
    button_down <= '0';
    button_left <= '0';

    wait for 5 ms;

    wait;
  end process;

end behavior;
