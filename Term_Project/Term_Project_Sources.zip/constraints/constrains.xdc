set_property PACKAGE_PIN W5 [get_ports system_clock]
set_property IOSTANDARD LVCMOS33 [get_ports system_clock]
create_clock -add -name sys_clk_pin -period 10.00 -waveform {0 5} [get_ports system_clock]

set_property PACKAGE_PIN J1 [get_ports ldr_input]
set_property IOSTANDARD LVCMOS33 [get_ports ldr_input]

set_property PACKAGE_PIN L2 [get_ports sensor_trigger]
set_property IOSTANDARD LVCMOS33 [get_ports sensor_trigger]

set_property PACKAGE_PIN J2 [get_ports sensor_echo]
set_property IOSTANDARD LVCMOS33 [get_ports sensor_echo]

set_property PACKAGE_PIN G2 [get_ports alarm_buzzer]
set_property IOSTANDARD LVCMOS33 [get_ports alarm_buzzer]

set_property PACKAGE_PIN U16 [get_ports alarm_led]
set_property IOSTANDARD LVCMOS33 [get_ports alarm_led]

set_property PACKAGE_PIN E19 [get_ports ldr_status_led]
set_property IOSTANDARD LVCMOS33 [get_ports ldr_status_led]

set_property PACKAGE_PIN T18 [get_ports button_up]

set_property IOSTANDARD LVCMOS33 [get_ports button_up]
set_property PACKAGE_PIN U17 [get_ports button_down]
set_property IOSTANDARD LVCMOS33 [get_ports button_down]
set_property PACKAGE_PIN W19 [get_ports button_left]
set_property IOSTANDARD LVCMOS33 [get_ports button_left]

set_property PACKAGE_PIN U7 [get_ports {segment_out[6]}]
set_property IOSTANDARD LVCMOS33 [get_ports {segment_out[6]}]
set_property PACKAGE_PIN V5 [get_ports {segment_out[5]}]
set_property IOSTANDARD LVCMOS33 [get_ports {segment_out[5]}]
set_property PACKAGE_PIN U5 [get_ports {segment_out[4]}]
set_property IOSTANDARD LVCMOS33 [get_ports {segment_out[4]}]
set_property PACKAGE_PIN V8 [get_ports {segment_out[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {segment_out[3]}]
set_property PACKAGE_PIN U8 [get_ports {segment_out[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {segment_out[2]}]
set_property PACKAGE_PIN W6 [get_ports {segment_out[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {segment_out[1]}]
set_property PACKAGE_PIN W7 [get_ports {segment_out[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {segment_out[0]}]

set_property PACKAGE_PIN U2 [get_ports {anode_out[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {anode_out[0]}]

set_property PACKAGE_PIN U4 [get_ports {anode_out[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {anode_out[1]}]
set_property PACKAGE_PIN V4 [get_ports {anode_out[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {anode_out[2]}]
set_property PACKAGE_PIN W4 [get_ports {anode_out[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {anode_out[3]}]

set_property PACKAGE_PIN H1 [get_ports ext_countdown_led]
set_property IOSTANDARD LVCMOS33 [get_ports ext_countdown_led]
