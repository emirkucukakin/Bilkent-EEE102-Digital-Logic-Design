library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity master_fsm is
  Port ( system_clock       : in STD_LOGIC;
      tick_1sec        : in STD_LOGIC;
      distance_in       : in integer range 0 to 999;
      ldr_input        : in STD_LOGIC;
      button_up          : in STD_LOGIC;
      button_down         : in STD_LOGIC;

        button_left     : in STD_LOGIC;
        display_value    : out integer range 0 to 999;
        buzzer_out      : out STD_LOGIC;
        alarm_led       : out STD_LOGIC;
        ext_countdown_led : out STD_LOGIC);
end master_fsm;

architecture Behavioral of master_fsm is
  type state_type is (SAFE, COUNTDOWN, LOCKED);
  signal current_state : state_type := SAFE;

  signal timer : integer range 0 to 10 := 0;
  signal password_step : integer range 0 to 3 := 0;

  signal up_prev, down_prev, left_prev : STD_LOGIC := '0';
begin
  process(system_clock)
  begin
    if rising_edge(system_clock) then
        up_prev <= button_up;
        down_prev <= button_down;
        left_prev <= button_left;

     case current_state is
       when SAFE =>
         buzzer_out <= '0';
         alarm_led <= '0';
         ext_countdown_led <= '0';
         display_value <= distance_in;
         password_step <= 0;

         if distance_in < 40 and distance_in > 0 then
           current_state <= COUNTDOWN;
           if ldr_input = '1' then
              timer <= 10;
           else
              timer <= 5;
           end if;
         end if;

       when COUNTDOWN =>
         display_value <= timer;
         buzzer_out <= '0';
         alarm_led <= '0';
         ext_countdown_led <= '1';

         if distance_in >= 40 then
           current_state <= SAFE;
         end if;

         if tick_1sec = '1' then
           if timer > 0 then
             timer <= timer - 1;
           else
             current_state <= LOCKED;
           end if;
         end if;

       when LOCKED =>
         display_value <= 0;
         buzzer_out <= '1';
         alarm_led <= '1';
         ext_countdown_led <= '0';

         if (button_up = '1' and up_prev = '0') then
           password_step <= 1;
         elsif (button_down = '1' and down_prev = '0') then
           if password_step = 1 then
             password_step <= 2;

                else
                  password_step <= 0;
                end if;
              elsif (button_left = '1' and left_prev = '0') then
                if password_step = 2 then
                  current_state <= SAFE;
                  password_step <= 0;
                else
                  password_step <= 0;
                end if;
              end if;

       end case;
    end if;
  end process;
end Behavioral;
