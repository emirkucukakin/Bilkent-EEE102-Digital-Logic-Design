library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity ultrasonic_controller is
  Port ( system_clock : in STD_LOGIC;
      tick_1us : in STD_LOGIC;

        sensor_echo : in STD_LOGIC;
        sensor_trigger : out STD_LOGIC;
        distance_out : out integer range 0 to 999);
end ultrasonic_controller;

architecture Behavioral of ultrasonic_controller is
  type state_type is (WAIT_STATE, TRIGGER_STATE, MEASURE_STATE, CALC_STATE);
  signal current_state : state_type := WAIT_STATE;

  signal timer : integer := 0;
  signal echo_time : integer := 0;
begin
  process(system_clock)
  begin
    if rising_edge(system_clock) then
        if tick_1us = '1' then
          case current_state is
             when WAIT_STATE =>
               sensor_trigger <= '0';
               if timer >= 60000 then
                 timer <= 0;
                 current_state <= TRIGGER_STATE;
               else

             timer <= timer + 1;
           end if;

         when TRIGGER_STATE =>
           sensor_trigger <= '1';
           if timer >= 10 then
             timer <= 0;
             current_state <= MEASURE_STATE;
           else
             timer <= timer + 1;
           end if;

         when MEASURE_STATE =>
           sensor_trigger <= '0';
           if sensor_echo = '1' then
             echo_time <= echo_time + 1;
           elsif echo_time > 0 and sensor_echo = '0' then
             current_state <= CALC_STATE;
           end if;

           if echo_time > 30000 then
             current_state <= CALC_STATE;
           end if;

              when CALC_STATE =>
                 distance_out <= echo_time / 58;
                 echo_time <= 0;
                 current_state <= WAIT_STATE;
         end case;
       end if;
    end if;
  end process;
end Behavioral;
