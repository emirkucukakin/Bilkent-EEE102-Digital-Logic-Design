library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity top_module is
  Port ( system_clock      : in STD_LOGIC;
      ldr_input        : in STD_LOGIC;
      sensor_echo        : in STD_LOGIC;
      button_up         : in STD_LOGIC;
      button_down         : in STD_LOGIC;

     button_left       : in STD_LOGIC;
     sensor_trigger     : out STD_LOGIC;
     alarm_buzzer       : out STD_LOGIC;
     alarm_led         : out STD_LOGIC;
     ldr_status_led     : out STD_LOGIC;
     ext_countdown_led : out STD_LOGIC;
     segment_out         : out STD_LOGIC_VECTOR (6 downto 0);
     anode_out          : out STD_LOGIC_VECTOR (3 downto 0));
end top_module;

architecture Behavioral of top_module is

  component clock_divider
    Port ( system_clock : in STD_LOGIC;
        tick_1us   : out STD_LOGIC;
        tick_1sec : out STD_LOGIC);
  end component;

  component ultrasonic_controller
    Port ( system_clock : in STD_LOGIC;
        tick_1us      : in STD_LOGIC;
        sensor_echo : in STD_LOGIC;
        sensor_trigger : out STD_LOGIC;

      distance_out : out integer range 0 to 999);
 end component;

 component master_fsm
   Port ( system_clock      : in STD_LOGIC;
      tick_1sec       : in STD_LOGIC;
      distance_in      : in integer range 0 to 999;
      ldr_input       : in STD_LOGIC;
      button_up          : in STD_LOGIC;
      button_down         : in STD_LOGIC;
      button_left      : in STD_LOGIC;
      display_value      : out integer range 0 to 999;
      buzzer_out         : out STD_LOGIC;
      alarm_led       : out STD_LOGIC;
      ext_countdown_led : out STD_LOGIC);
 end component;

 component seven_segment_driver
   Port ( system_clock : in STD_LOGIC;
      distance_in : in integer range 0 to 999;
      segment_out : out STD_LOGIC_VECTOR (6 downto 0);
      anode_out : out STD_LOGIC_VECTOR (3 downto 0));
 end component;

  signal tick_1us_sig : STD_LOGIC;
  signal tick_1sec_sig : STD_LOGIC;
  signal raw_dist_sig : integer range 0 to 999;
  signal final_disp_sig : integer range 0 to 999;

begin
  ldr_status_led <= ldr_input;

  Inst_clock_divider: clock_divider port map(
       system_clock => system_clock,
       tick_1us   => tick_1us_sig,
       tick_1sec => tick_1sec_sig
  );

  Inst_ultrasonic: ultrasonic_controller port map(
       system_clock => system_clock,
       tick_1us    => tick_1us_sig,
       sensor_echo => sensor_echo,
       sensor_trigger => sensor_trigger,
       distance_out => raw_dist_sig
  );

  Inst_master_fsm: master_fsm port map(
       system_clock      => system_clock,
       tick_1sec       => tick_1sec_sig,
       distance_in      => raw_dist_sig,
       ldr_input       => ldr_input,
       button_up        => button_up,
       button_down        => button_down,
       button_left      => button_left,
       display_value     => final_disp_sig,
       buzzer_out       => alarm_buzzer,
       alarm_led       => alarm_led,
       ext_countdown_led => ext_countdown_led
  );

  Inst_display: seven_segment_driver port map(
       system_clock => system_clock,
       distance_in => final_disp_sig,
       segment_out => segment_out,
       anode_out => anode_out
  );

end Behavioral;
