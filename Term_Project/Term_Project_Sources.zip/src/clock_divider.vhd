library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity clock_divider is
  Port ( system_clock : in STD_LOGIC;
        tick_1us : out STD_LOGIC;
        tick_1sec : out STD_LOGIC);
end clock_divider;

architecture Behavioral of clock_divider is
  signal counter_1us : integer range 0 to 99 := 0;
  signal counter_1sec : integer range 0 to 99999999 := 0;
begin
  process(system_clock)
  begin
    if rising_edge(system_clock) then

        if counter_1us = 99 then
          counter_1us <= 0;
          tick_1us <= '1';
        else
          counter_1us <= counter_1us + 1;

         tick_1us <= '0';
       end if;

       if counter_1sec = 99999999 then
         counter_1sec <= 0;
         tick_1sec <= '1';
       else
         counter_1sec <= counter_1sec + 1;
         tick_1sec <= '0';
       end if;
    end if;
  end process;
end Behavioral;
