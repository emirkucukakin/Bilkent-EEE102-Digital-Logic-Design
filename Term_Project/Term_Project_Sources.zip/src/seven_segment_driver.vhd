library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity seven_segment_driver is

  Port ( system_clock : in STD_LOGIC;
        distance_in : in integer range 0 to 999;
        segment_out : out STD_LOGIC_VECTOR (6 downto 0);
        anode_out : out STD_LOGIC_VECTOR (3 downto 0));
end seven_segment_driver;

architecture Behavioral of seven_segment_driver is
  signal refresh_counter : unsigned(19 downto 0) := (others => '0');
  signal active_digit : STD_LOGIC_VECTOR(1 downto 0);
  signal bcd_digit : integer range 0 to 9;

  signal hundreds : integer range 0 to 9;
  signal tens : integer range 0 to 9;
  signal ones : integer range 0 to 9;
begin

  hundreds <= distance_in / 100;
  tens <= (distance_in mod 100) / 10;
  ones <= distance_in mod 10;

  process(system_clock)
  begin

   if rising_edge(system_clock) then
     refresh_counter <= refresh_counter + 1;
   end if;
 end process;

 active_digit <= std_logic_vector(refresh_counter(19 downto 18));

 process(active_digit, hundreds, tens, ones)
 begin
   case active_digit is
     when "00" =>
         anode_out <= "1110";
         bcd_digit <= ones;
     when "01" =>
         anode_out <= "1101";
         bcd_digit <= tens;
     when "10" =>
         anode_out <= "1011";
         bcd_digit <= hundreds;
     when others =>
         anode_out <= "1111";
         bcd_digit <= 0;

    end case;
  end process;

  process(bcd_digit)
  begin
    case bcd_digit is
      when 0 => segment_out <= "1000000";
      when 1 => segment_out <= "1111001";
      when 2 => segment_out <= "0100100";
      when 3 => segment_out <= "0110000";
      when 4 => segment_out <= "0011001";
      when 5 => segment_out <= "0010010";
      when 6 => segment_out <= "0000010";
      when 7 => segment_out <= "1111000";
      when 8 => segment_out <= "0000000";
      when 9 => segment_out <= "0010000";
      when others => segment_out <= "1111111";
    end case;
  end process;
end Behavioral;
