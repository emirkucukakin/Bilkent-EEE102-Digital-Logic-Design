-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Sun Mar 29 13:50:33 2026
-- Host        : AsusEmirK running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/emirk/project_5/project_5.gen/sources_1/bd/design_1/ip/design_1_arbitrary_waveform_0_0/design_1_arbitrary_waveform_0_0_stub.vhdl
-- Design      : design_1_arbitrary_waveform_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design_1_arbitrary_waveform_0_0 is
  Port ( 
    clk_50MHz : in STD_LOGIC;
    reset_in : in STD_LOGIC;
    wave_out : out STD_LOGIC
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_arbitrary_waveform_0_0 : entity is "design_1_arbitrary_waveform_0_0,arbitrary_waveform,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of design_1_arbitrary_waveform_0_0 : entity is "design_1_arbitrary_waveform_0_0,arbitrary_waveform,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=arbitrary_waveform,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_1_arbitrary_waveform_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_1_arbitrary_waveform_0_0 : entity is "module_ref";
end design_1_arbitrary_waveform_0_0;

architecture stub of design_1_arbitrary_waveform_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "clk_50MHz,reset_in,wave_out";
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of reset_in : signal is "xilinx.com:signal:reset:1.0 reset_in RST";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of reset_in : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of reset_in : signal is "XIL_INTERFACENAME reset_in, POLARITY ACTIVE_HIGH, INSERT_VIP 0";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "arbitrary_waveform,Vivado 2025.2";
begin
end;
