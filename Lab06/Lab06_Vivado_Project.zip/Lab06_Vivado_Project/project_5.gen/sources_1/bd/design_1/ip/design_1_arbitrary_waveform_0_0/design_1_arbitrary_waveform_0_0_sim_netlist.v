// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Sun Mar 29 13:50:33 2026
// Host        : AsusEmirK running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/emirk/project_5/project_5.gen/sources_1/bd/design_1/ip/design_1_arbitrary_waveform_0_0/design_1_arbitrary_waveform_0_0_sim_netlist.v
// Design      : design_1_arbitrary_waveform_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_arbitrary_waveform_0_0,arbitrary_waveform,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "arbitrary_waveform,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module design_1_arbitrary_waveform_0_0
   (clk_50MHz,
    reset_in,
    wave_out);
  input clk_50MHz;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 reset_in RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME reset_in, POLARITY ACTIVE_HIGH, INSERT_VIP 0" *) input reset_in;
  output wave_out;

  wire clk_50MHz;
  wire reset_in;
  wire wave_out;

  design_1_arbitrary_waveform_0_0_arbitrary_waveform inst
       (.clk_50MHz(clk_50MHz),
        .reset_in(reset_in),
        .wave_out(wave_out));
endmodule

(* ORIG_REF_NAME = "arbitrary_waveform" *) 
module design_1_arbitrary_waveform_0_0_arbitrary_waveform
   (wave_out,
    reset_in,
    clk_50MHz);
  output wave_out;
  input reset_in;
  input clk_50MHz;

  wire \FSM_sequential_current_state[0]_i_1_n_0 ;
  wire \FSM_sequential_current_state[0]_i_3_n_0 ;
  wire \FSM_sequential_current_state[0]_i_4_n_0 ;
  wire \FSM_sequential_current_state[0]_i_5_n_0 ;
  wire \FSM_sequential_current_state[0]_i_6_n_0 ;
  wire \FSM_sequential_current_state[1]_i_1_n_0 ;
  wire \FSM_sequential_current_state[1]_i_2_n_0 ;
  wire \FSM_sequential_current_state[1]_i_3_n_0 ;
  wire \FSM_sequential_current_state[1]_i_4_n_0 ;
  wire clk_50MHz;
  wire counter0_carry__0_n_0;
  wire counter0_carry__0_n_1;
  wire counter0_carry__0_n_2;
  wire counter0_carry__0_n_3;
  wire counter0_carry__0_n_4;
  wire counter0_carry__0_n_5;
  wire counter0_carry__0_n_6;
  wire counter0_carry__0_n_7;
  wire counter0_carry__1_n_2;
  wire counter0_carry__1_n_3;
  wire counter0_carry__1_n_5;
  wire counter0_carry__1_n_6;
  wire counter0_carry__1_n_7;
  wire counter0_carry_n_0;
  wire counter0_carry_n_1;
  wire counter0_carry_n_2;
  wire counter0_carry_n_3;
  wire counter0_carry_n_4;
  wire counter0_carry_n_5;
  wire counter0_carry_n_6;
  wire counter0_carry_n_7;
  wire \counter[0]_i_1_n_0 ;
  wire \counter[10]_i_1_n_0 ;
  wire \counter[11]_i_1_n_0 ;
  wire \counter[1]_i_1_n_0 ;
  wire \counter[2]_i_1_n_0 ;
  wire \counter[3]_i_1_n_0 ;
  wire \counter[4]_i_1_n_0 ;
  wire \counter[5]_i_1_n_0 ;
  wire \counter[6]_i_1_n_0 ;
  wire \counter[7]_i_1_n_0 ;
  wire \counter[8]_i_1_n_0 ;
  wire \counter[9]_i_1_n_0 ;
  wire \counter_reg_n_0_[0] ;
  wire \counter_reg_n_0_[10] ;
  wire \counter_reg_n_0_[11] ;
  wire \counter_reg_n_0_[1] ;
  wire \counter_reg_n_0_[2] ;
  wire \counter_reg_n_0_[3] ;
  wire \counter_reg_n_0_[4] ;
  wire \counter_reg_n_0_[5] ;
  wire \counter_reg_n_0_[6] ;
  wire \counter_reg_n_0_[7] ;
  wire \counter_reg_n_0_[8] ;
  wire \counter_reg_n_0_[9] ;
  wire [1:0]current_state;
  wire p_0_in;
  wire reset_in;
  wire wave_out;
  wire wave_out_i_1_n_0;
  wire [3:2]NLW_counter0_carry__1_CO_UNCONNECTED;
  wire [3:3]NLW_counter0_carry__1_O_UNCONNECTED;

  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hAAAA03F3)) 
    \FSM_sequential_current_state[0]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[1]),
        .I3(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I4(current_state[0]),
        .O(\FSM_sequential_current_state[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF10FFFFFF)) 
    \FSM_sequential_current_state[0]_i_2 
       (.I0(\counter_reg_n_0_[6] ),
        .I1(\counter_reg_n_0_[5] ),
        .I2(\FSM_sequential_current_state[0]_i_4_n_0 ),
        .I3(\counter_reg_n_0_[11] ),
        .I4(\counter_reg_n_0_[9] ),
        .I5(\FSM_sequential_current_state[0]_i_5_n_0 ),
        .O(p_0_in));
  LUT6 #(
    .INIT(64'h7F7F7F7F777F7777)) 
    \FSM_sequential_current_state[0]_i_3 
       (.I0(\counter_reg_n_0_[11] ),
        .I1(\counter_reg_n_0_[10] ),
        .I2(\counter_reg_n_0_[9] ),
        .I3(\counter_reg_n_0_[6] ),
        .I4(\FSM_sequential_current_state[0]_i_6_n_0 ),
        .I5(\FSM_sequential_current_state[1]_i_3_n_0 ),
        .O(\FSM_sequential_current_state[0]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \FSM_sequential_current_state[0]_i_4 
       (.I0(\counter_reg_n_0_[0] ),
        .I1(\counter_reg_n_0_[1] ),
        .I2(\counter_reg_n_0_[2] ),
        .I3(\counter_reg_n_0_[4] ),
        .I4(\counter_reg_n_0_[3] ),
        .O(\FSM_sequential_current_state[0]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \FSM_sequential_current_state[0]_i_5 
       (.I0(\counter_reg_n_0_[8] ),
        .I1(\counter_reg_n_0_[7] ),
        .I2(\counter_reg_n_0_[10] ),
        .O(\FSM_sequential_current_state[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h5555777755557FFF)) 
    \FSM_sequential_current_state[0]_i_6 
       (.I0(\counter_reg_n_0_[5] ),
        .I1(\counter_reg_n_0_[3] ),
        .I2(\counter_reg_n_0_[1] ),
        .I3(\counter_reg_n_0_[0] ),
        .I4(\counter_reg_n_0_[4] ),
        .I5(\counter_reg_n_0_[2] ),
        .O(\FSM_sequential_current_state[0]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'hA6)) 
    \FSM_sequential_current_state[1]_i_1 
       (.I0(current_state[1]),
        .I1(current_state[0]),
        .I2(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .O(\FSM_sequential_current_state[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000000FDFFFFFFFF)) 
    \FSM_sequential_current_state[1]_i_2 
       (.I0(\counter_reg_n_0_[6] ),
        .I1(\FSM_sequential_current_state[1]_i_3_n_0 ),
        .I2(\FSM_sequential_current_state[1]_i_4_n_0 ),
        .I3(\counter_reg_n_0_[9] ),
        .I4(\counter_reg_n_0_[10] ),
        .I5(\counter_reg_n_0_[11] ),
        .O(\FSM_sequential_current_state[1]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \FSM_sequential_current_state[1]_i_3 
       (.I0(\counter_reg_n_0_[7] ),
        .I1(\counter_reg_n_0_[8] ),
        .O(\FSM_sequential_current_state[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000100010001)) 
    \FSM_sequential_current_state[1]_i_4 
       (.I0(\counter_reg_n_0_[4] ),
        .I1(\counter_reg_n_0_[5] ),
        .I2(\counter_reg_n_0_[2] ),
        .I3(\counter_reg_n_0_[3] ),
        .I4(\counter_reg_n_0_[0] ),
        .I5(\counter_reg_n_0_[1] ),
        .O(\FSM_sequential_current_state[1]_i_4_n_0 ));
  (* FSM_ENCODED_STATES = "s_high_80:00,s_low_50_1:01,s_high_70:10,s_low_50_2:11" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_current_state_reg[0] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\FSM_sequential_current_state[0]_i_1_n_0 ),
        .Q(current_state[0]),
        .R(reset_in));
  (* FSM_ENCODED_STATES = "s_high_80:00,s_low_50_1:01,s_high_70:10,s_low_50_2:11" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_current_state_reg[1] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\FSM_sequential_current_state[1]_i_1_n_0 ),
        .Q(current_state[1]),
        .R(reset_in));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 counter0_carry
       (.CI(1'b0),
        .CO({counter0_carry_n_0,counter0_carry_n_1,counter0_carry_n_2,counter0_carry_n_3}),
        .CYINIT(\counter_reg_n_0_[0] ),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({counter0_carry_n_4,counter0_carry_n_5,counter0_carry_n_6,counter0_carry_n_7}),
        .S({\counter_reg_n_0_[4] ,\counter_reg_n_0_[3] ,\counter_reg_n_0_[2] ,\counter_reg_n_0_[1] }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 counter0_carry__0
       (.CI(counter0_carry_n_0),
        .CO({counter0_carry__0_n_0,counter0_carry__0_n_1,counter0_carry__0_n_2,counter0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({counter0_carry__0_n_4,counter0_carry__0_n_5,counter0_carry__0_n_6,counter0_carry__0_n_7}),
        .S({\counter_reg_n_0_[8] ,\counter_reg_n_0_[7] ,\counter_reg_n_0_[6] ,\counter_reg_n_0_[5] }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 counter0_carry__1
       (.CI(counter0_carry__0_n_0),
        .CO({NLW_counter0_carry__1_CO_UNCONNECTED[3:2],counter0_carry__1_n_2,counter0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_counter0_carry__1_O_UNCONNECTED[3],counter0_carry__1_n_5,counter0_carry__1_n_6,counter0_carry__1_n_7}),
        .S({1'b0,\counter_reg_n_0_[11] ,\counter_reg_n_0_[10] ,\counter_reg_n_0_[9] }));
  LUT6 #(
    .INIT(64'h00000000AFACA0AC)) 
    \counter[0]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(\counter_reg_n_0_[0] ),
        .O(\counter[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[10]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry__1_n_6),
        .O(\counter[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[11]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry__1_n_5),
        .O(\counter[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[1]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry_n_7),
        .O(\counter[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[2]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry_n_6),
        .O(\counter[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[3]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry_n_5),
        .O(\counter[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[4]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry_n_4),
        .O(\counter[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[5]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry__0_n_7),
        .O(\counter[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[6]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry__0_n_6),
        .O(\counter[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[7]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry__0_n_5),
        .O(\counter[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[8]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry__0_n_4),
        .O(\counter[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFACA0AC00000000)) 
    \counter[9]_i_1 
       (.I0(\FSM_sequential_current_state[1]_i_2_n_0 ),
        .I1(p_0_in),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .I4(\FSM_sequential_current_state[0]_i_3_n_0 ),
        .I5(counter0_carry__1_n_7),
        .O(\counter[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[0] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[0]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[0] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[10] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[10]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[10] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[11] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[11]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[11] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[1] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[1]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[1] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[2] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[2]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[2] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[3] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[3]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[3] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[4] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[4]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[4] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[5] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[5]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[5] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[6] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[6]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[6] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[7] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[7]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[7] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[8] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[8]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[8] ),
        .R(reset_in));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg[9] 
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(\counter[9]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[9] ),
        .R(reset_in));
  LUT1 #(
    .INIT(2'h1)) 
    wave_out_i_1
       (.I0(current_state[0]),
        .O(wave_out_i_1_n_0));
  FDRE wave_out_reg
       (.C(clk_50MHz),
        .CE(1'b1),
        .D(wave_out_i_1_n_0),
        .Q(wave_out),
        .R(reset_in));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
