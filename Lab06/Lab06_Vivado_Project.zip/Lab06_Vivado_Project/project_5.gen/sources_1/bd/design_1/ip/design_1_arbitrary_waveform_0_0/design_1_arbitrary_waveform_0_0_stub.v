// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Sun Mar 29 13:50:33 2026
// Host        : AsusEmirK running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/emirk/project_5/project_5.gen/sources_1/bd/design_1/ip/design_1_arbitrary_waveform_0_0/design_1_arbitrary_waveform_0_0_stub.v
// Design      : design_1_arbitrary_waveform_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "design_1_arbitrary_waveform_0_0,arbitrary_waveform,{}" *) (* CORE_GENERATION_INFO = "design_1_arbitrary_waveform_0_0,arbitrary_waveform,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=arbitrary_waveform,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "arbitrary_waveform,Vivado 2025.2" *) 
module design_1_arbitrary_waveform_0_0(clk_50MHz, reset_in, wave_out)
/* synthesis syn_black_box black_box_pad_pin="reset_in,wave_out" */
/* synthesis syn_force_seq_prim="clk_50MHz" */;
  input clk_50MHz /* synthesis syn_isclock = 1 */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 reset_in RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME reset_in, POLARITY ACTIVE_HIGH, INSERT_VIP 0" *) input reset_in;
  output wave_out;
endmodule
