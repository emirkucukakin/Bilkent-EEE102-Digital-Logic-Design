library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Arbitrary_Waveform_tb is
end Arbitrary_Waveform_tb;

architecture Behavioral of Arbitrary_Waveform_tb is

    component Arbitrary_Waveform
        port(
            clk_in   : in std_logic;
            reset_in : in std_logic;
            wave_out : out std_logic
        );
    end component;

    signal tb_clk_in   : std_logic := '0';
    signal tb_reset_in : std_logic := '0';
    signal tb_wave_out : std_logic;


    constant C_CLK_PERIOD : time := 10 ns; 

begin

    uut: Arbitrary_Waveform PORT MAP (
        clk_in   => tb_clk_in,
        reset_in => tb_reset_in,
        wave_out => tb_wave_out
    );

    clk_process : process
    begin
        tb_clk_in <= '0';
        wait for C_CLK_PERIOD / 2;
        tb_clk_in <= '1';
        wait for C_CLK_PERIOD / 2;
    end process;

    stim_proc : process
    begin
        tb_reset_in <= '1';
        wait for 100 ns;
        tb_reset_in <= '0';
        wait for 1000 us;
        wait;
    end process;

end Behavioral;