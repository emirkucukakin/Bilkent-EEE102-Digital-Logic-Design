library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_design_1_wrapper is
end tb_design_1_wrapper;

architecture Behavioral of tb_design_1_wrapper is

    component design_1_wrapper is
        port (
            reset_rtl_0 : in STD_LOGIC;
            clk_100MHz : in STD_LOGIC;
            wave_out_0 : out STD_LOGIC
        );
    end component;

    signal tb_clk : std_logic := '0';
    signal tb_reset : std_logic := '0';
    signal tb_wave_out : std_logic;

    constant C_CLK_PERIOD : time := 10 ns;

begin

    uut: design_1_wrapper port map (
        reset_rtl_0 => tb_reset,
        clk_100MHz => tb_clk,
        wave_out_0 => tb_wave_out
    );

    clk_process : process
    begin
        tb_clk <= '0';
        wait for C_CLK_PERIOD / 2;
        tb_clk <= '1';
        wait for C_CLK_PERIOD / 2;
    end process;

    stim_proc : process
    begin
        tb_reset <= '1';
        wait for 100 ns;
        tb_reset <= '0';
        wait for 1000 us;
        wait;
    end process;

end Behavioral;