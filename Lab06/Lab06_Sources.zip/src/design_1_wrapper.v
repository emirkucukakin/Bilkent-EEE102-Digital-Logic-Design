`timescale 1 ps / 1 ps

module design_1_wrapper
 (clk_100MHz,
  reset_rtl_0,
  wave_out_0);
 input clk_100MHz;
 input reset_rtl_0;
 output wave_out_0;

 wire clk_100MHz;
 wire reset_rtl_0;
 wire wave_out_0;

 design_1 design_1_i
   (.clk_100MHz(clk_100MHz),
    .reset_rtl_0(reset_rtl_0),
    .wave_out_0(wave_out_0));
endmodule
