library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity arbitrary_waveform is
  Port (
       clk_50MHz : in STD_LOGIC;
       reset_in : in STD_LOGIC;
       wave_out : out STD_LOGIC
  );
end arbitrary_waveform;

architecture Behavioral of arbitrary_waveform is

  type state_type is (S_HIGH_80, S_LOW_50_1, S_HIGH_70, S_LOW_50_2);
  signal current_state : state_type := S_HIGH_80;

 signal counter : integer range 0 to 4000 := 0;

 constant C_80US : integer := 4000;
 constant C_50US : integer := 2500;
 constant C_70US : integer := 3500;

begin

 process(clk_50MHz)
 begin
   if rising_edge(clk_50MHz) then
        if reset_in = '1' then
          current_state <= S_HIGH_80;
          counter <= 0;
          wave_out <= '0';
        else
          case current_state is
            when S_HIGH_80 =>
               wave_out <= '1';
               if counter < C_80US - 1 then
                 counter <= counter + 1;
               else
                 counter <= 0;
                 current_state <= S_LOW_50_1;
               end if;

            when S_LOW_50_1 =>
               wave_out <= '0';
               if counter < C_50US - 1 then

               counter <= counter + 1;
             else
               counter <= 0;
               current_state <= S_HIGH_70;
             end if;

         when S_HIGH_70 =>
             wave_out <= '1';
             if counter < C_70US - 1 then
               counter <= counter + 1;
             else
               counter <= 0;
               current_state <= S_LOW_50_2;
             end if;

         when S_LOW_50_2 =>
             wave_out <= '0';
             if counter < C_50US - 1 then
               counter <= counter + 1;
             else
               counter <= 0;
               current_state <= S_HIGH_80;
             end if;
       end case;
     end if;
   end if;
 end process;

end Behavioral;
