library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
entity tb_top_module is
end tb_top_module;
architecture Behavioral of tb_top_module is
  -- Signals to connect to the DUT
  signal i_SW : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
  signal o_LED : STD_LOGIC_VECTOR(7 downto 0);
  -- Component declaration of the top module
  component top_module is
    Port (
         i_SW : in STD_LOGIC_VECTOR (7 downto 0);
         o_LED : out STD_LOGIC_VECTOR (7 downto 0)
    );
  end component;

begin
 -- Instantiate the Device Under Test (DUT)
 DUT : top_module
   port map (
        i_SW => i_SW,
        o_LED => o_LED
   );
 -- Stimulus process: apply all 256 combinations sequentially
 stim_proc : process
 begin
   for i in 0 to 255 loop
        i_SW <= std_logic_vector(to_unsigned(i, 8));
        wait for 10 ns;
   end loop;
   wait; -- stop simulation
 end process;
end Behavioral;
